using System;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Windows.Forms;

namespace VAGDiagTool
{
    public class MainForm : Form
    {
        private TextBox txtCode;
        private Button btnSearch;
        private Label lblSystemeValue;
        private Label lblLibelleValue;
        private TextBox txtDetails;
        private Label lblStatus;

        private JsonObject? codes;

        public MainForm()
        {
            this.Text = "VAGDiag – Décodeur codes VAG";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Width = 640;
            this.Height = 420;

            InitializeMenu();
            InitializeControls();
            LoadCodes();
        }

        private void InitializeMenu()
        {
            var menu = new MenuStrip();

            var fichier = new ToolStripMenuItem("Fichier");
            var miQuitter = new ToolStripMenuItem("Quitter", null, (_, __) => this.Close());
            fichier.DropDownItems.Add(miQuitter);

            var aide = new ToolStripMenuItem("Aide");
            var miPaypal = new ToolStripMenuItem("Soutenir le projet (PayPal)", null, OnPaypalClick);
            var miAPropos = new ToolStripMenuItem("À propos", null, OnAboutClick);
            aide.DropDownItems.Add(miPaypal);
            aide.DropDownItems.Add(new ToolStripSeparator());
            aide.DropDownItems.Add(miAPropos);

            menu.Items.Add(fichier);
            menu.Items.Add(aide);

            this.MainMenuStrip = menu;
            this.Controls.Add(menu);
        }

        private void InitializeControls()
        {
            var pnl = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(10)
            };
            this.Controls.Add(pnl);

            var lblTitle = new Label
            {
                Text = "Décodeur VAG – VW / Audi / Seat / Skoda",
                AutoSize = true,
                Font = new System.Drawing.Font("Segoe UI", 11, System.Drawing.FontStyle.Bold),
                Top = 10,
                Left = 10
            };
            pnl.Controls.Add(lblTitle);

            var lblSub = new Label
            {
                Text = "Entre un code défaut VAG ou OBD (ex : 17965, 01314, P0299…).",
                AutoSize = true,
                Top = lblTitle.Bottom + 4,
                Left = 10
            };
            pnl.Controls.Add(lblSub);

            var lblCode = new Label
            {
                Text = "Code défaut :",
                AutoSize = true,
                Top = lblSub.Bottom + 12,
                Left = 10
            };
            pnl.Controls.Add(lblCode);

            txtCode = new TextBox
            {
                Width = 120,
                Top = lblCode.Top - 3,
                Left = lblCode.Right + 10
            };
            txtCode.KeyDown += TxtCode_KeyDown;
            pnl.Controls.Add(txtCode);

            btnSearch = new Button
            {
                Text = "Rechercher",
                Left = txtCode.Right + 10,
                Top = txtCode.Top - 1,
                Width = 100
            };
            btnSearch.Click += (_, __) => Search();
            pnl.Controls.Add(btnSearch);

            var lblSysteme = new Label
            {
                Text = "Système :",
                AutoSize = true,
                Top = txtCode.Bottom + 18,
                Left = 10
            };
            pnl.Controls.Add(lblSysteme);

            lblSystemeValue = new Label
            {
                AutoSize = true,
                Top = lblSysteme.Top,
                Left = lblSysteme.Right + 8
            };
            pnl.Controls.Add(lblSystemeValue);

            var lblLibelle = new Label
            {
                Text = "Libellé :",
                AutoSize = true,
                Top = lblSysteme.Bottom + 8,
                Left = 10
            };
            pnl.Controls.Add(lblLibelle);

            lblLibelleValue = new Label
            {
                AutoSize = false,
                Top = lblLibelle.Top,
                Left = lblLibelle.Right + 8,
                Width = 560,
                Height = 32
            };
            pnl.Controls.Add(lblLibelleValue);

            txtDetails = new TextBox
            {
                Top = lblLibelle.Bottom + 8,
                Left = 10,
                Width = 600,
                Height = 200,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                ReadOnly = true
            };
            pnl.Controls.Add(txtDetails);

            lblStatus = new Label
            {
                AutoSize = true,
                Top = txtDetails.Bottom + 6,
                Left = 10,
                ForeColor = System.Drawing.Color.DimGray
            };
            pnl.Controls.Add(lblStatus);
        }

        private void TxtCode_KeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                Search();
            }
        }

        private void LoadCodes()
        {
            try
            {
                string exeDir = AppContext.BaseDirectory;
                string jsonPath = Path.Combine(exeDir, "vag_codes.json");
                if (!File.Exists(jsonPath))
                {
                    lblStatus.Text = "vag_codes.json introuvable. Aucun code chargé.";
                    return;
                }

                string json = File.ReadAllText(jsonPath);
                codes = JsonNode.Parse(json)?.AsObject();
                int count = codes?.Count ?? 0;
                lblStatus.Text = $"Base chargée : {count} code(s).";
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Erreur lors du chargement de vag_codes.json.";
                Debug.WriteLine(ex);
            }
        }

        private string NormalizeCode(string raw)
        {
            string code = raw.Trim().ToUpperInvariant();
            if (string.IsNullOrEmpty(code))
                return code;

            if (code.Length == 5 && code.StartsWith("P") && int.TryParse(code.AsSpan(1), out _))
                return code;

            if (int.TryParse(code, out _))
            {
                code = code.TrimStart('0');
                return code.Length == 0 ? "0" : code;
            }

            return code;
        }

        private string[] GetCandidates(string raw)
        {
            string norm = NormalizeCode(raw);
            var list = new System.Collections.Generic.List<string>();
            var seen = new System.Collections.Generic.HashSet<string>();

            void Add(string v)
            {
                if (!string.IsNullOrWhiteSpace(v) && seen.Add(v))
                    list.Add(v);
            }

            if (!string.IsNullOrEmpty(norm))
            {
                Add(norm);
                if (int.TryParse(norm, out _))
                    Add(norm.PadLeft(5, '0'));
            }

            string upper = raw.Trim().ToUpperInvariant();
            Add(upper);

            return list.ToArray();
        }

        private void Search()
        {
            txtDetails.Clear();
            lblSystemeValue.Text = "";
            lblLibelleValue.Text = "";
            lblStatus.Text = "";

            string input = txtCode.Text;
            if (string.IsNullOrWhiteSpace(input))
            {
                MessageBox.Show("Saisis un code avant de lancer la recherche.", "Information",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (codes == null)
            {
                MessageBox.Show("Aucune base chargée (vag_codes.json manquant ou invalide).", "Erreur",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            foreach (var candidate in GetCandidates(input))
            {
                if (codes.TryGetPropertyValue(candidate, out JsonNode? node) && node is JsonObject obj)
                {
                    string systeme = obj["systeme"]?.ToString() ?? "";
                    string libelle = obj["libelle"]?.ToString() ?? "";
                    string description = obj["description"]?.ToString() ?? "";
                    var commentaires = obj["commentaires"] as JsonArray;

                    lblSystemeValue.Text = systeme;
                    lblLibelleValue.Text = libelle;

                    var sb = new System.Text.StringBuilder();
                    if (!string.IsNullOrWhiteSpace(description))
                    {
                        sb.AppendLine("Description :");
                        sb.AppendLine(description);
                        sb.AppendLine();
                    }

                    if (commentaires != null && commentaires.Count > 0)
                    {
                        sb.AppendLine("Pistes :");
                        foreach (var c in commentaires)
                        {
                            if (c != null)
                                sb.AppendLine(" - " + c.ToString());
                        }
                    }

                    txtDetails.Text = sb.ToString();
                    lblStatus.Text = $"Code {candidate} trouvé.";
                    return;
                }
            }

            MessageBox.Show(
                $"Code « {input.Trim().ToUpperInvariant()} » non trouvé dans la base. " +
                "Ajoute-le dans vag_codes.json.",
                "Non trouvé",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            lblStatus.Text = "Code non trouvé.";
        }

        private void OnPaypalClick(object? sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "https://www.paypal.com/donate/?hosted_button_id=T9DK4J66CX9SS",
                    UseShellExecute = true
                });
            }
            catch { }
        }

        private void OnAboutClick(object? sender, EventArgs e)
        {
            MessageBox.Show(
                "VAGDiag – Décodeur de codes VAG\n" +
                "Auteur : Soufiane Mansour\n" +
                "Base locale : vag_codes.json",
                "À propos",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
    }
}