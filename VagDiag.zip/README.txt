VAGDiagTool (.NET 6, WinForms)

Contenu :
- VAGDiagTool.csproj  : projet .NET
- Program.cs          : point d'entrée
- MainForm.cs         : interface graphique et logique
- vag_codes.json      : base des codes VAG
- build.cmd           : script de compilation en EXE autonome

Prerequis :
- SDK .NET 6 (ou version supérieure) installé sur la machine
  https://dotnet.microsoft.com/en-us/download

Compilation (comme tu as fait pour NetDiagTool) :

1) Ouvre une fenêtre CMD dans ce dossier (NetDiagVAG par ex.).
2) Lance :
      build.cmd

3) A la fin tu trouveras :
      bin\Release\net6.0-windows\win-x64\publish\VAGDiagTool.exe

4) Pour distribuer :
   - Prends juste VAGDiagTool.exe + vag_codes.json
   - Tu peux zipper ou rar ces deux fichiers et les mettre sur ton GitHub
     comme tu as fait avec net6.0-windows.rar pour NetDiagTool.